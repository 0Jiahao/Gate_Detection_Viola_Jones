clear
clc
close all

[SENSOR,GT] = readLog();
%   checkGroundTruthAngularVelocity(GT);
% verifyDroneModelEarthFrame(GT);

% complementaryFilterAHRS(SENSOR,GT)
%  kalmanFilterAHRS(SENSOR,GT);

% verifyPredictionModel(GT);

INS(GT,SENSOR);
temp = 1;